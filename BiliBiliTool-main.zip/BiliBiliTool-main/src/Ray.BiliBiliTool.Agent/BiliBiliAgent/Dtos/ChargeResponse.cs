﻿namespace Ray.BiliBiliTool.Agent.BiliBiliAgent.Dtos
{
    public class ChargeResponse
    {
        public int Status { get; set; }

        public string Order_no { get; set; }
    }
}
